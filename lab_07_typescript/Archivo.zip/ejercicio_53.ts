import { Plato, Platos, menu } from "./ejercicio_52";

/**
 * Ejercicios 5.3
 *
 * 1. Almacenar la siguiente tipificación de un objeto en un tipo llamado 'ItemDePedido':
 * - cantidad: número
 * - plato: Plato
 *
 * 2. Crear un constante llamada 'pedido', tipificada como un conjunto de Items de Pedido,
 * inicializarla con por lo menos cuatro (4) ítems que cumplan la condición.
 *
 * 3. Declarar un función con nombre 'precioDelPedido' tipificada de la siguiente
 * manera:
 *
 * Parámetros
 * - platos: conjunto de Items de Pedido
 *
 * Retorno: número
 *
 * 4. La función 'precioDelPedido' debe contener las siguientes instrucciones:
 * - Declarar una variable con nombre 'acumuladorDePrecio', tipificada como un número e
 * inicializada con 0;
 * - Iterar sobre el conjunto de Items de Pedido almacenados en el parámetro 'platos'
 * con un bucle 'for' para sumar en el 'acumuladorDePrecio', en cada iteración, el 'precio'
 * por la 'cantidad' de cada 'plato'
 * - Retornar el 'acumuladorDePrecio'
 *
 * 5. Ejecutar e imprimir en la consola el resultado de la función 'precioDelPedido'
 * con los siguientes parámetros:
 * - platos: constante 'pedido'
 */

type ItemDePedido = {
  cantidad: number;
  plato: Plato;
};

/* 2. Crear un constante llamada 'pedido', tipificada como un conjunto de Items de Pedido,
 * inicializarla con por lo menos cuatro (4) ítems que cumplan la condición.*/

type Pedido = ItemDePedido[];
const pedido: Pedido = [
  { cantidad: 10, plato: menu[0] },
  { cantidad: 10, plato: menu[3] },
  { cantidad: 10, plato: menu[6] },
  { cantidad: 10, plato: menu[7] },
];

/* 3. Declarar un función con nombre 'precioDelPedido' tipificada de la siguiente
 * manera:
 *
 * Parámetros
 * - platos: conjunto de Items de Pedido
 *
 * Retorno: número */

/* 4. La función 'precioDelPedido' debe contener las siguientes instrucciones:
 * - Declarar una variable con nombre 'acumuladorDePrecio', tipificada como un número e
 * inicializada con 0;
 * - Iterar sobre el conjunto de Items de Pedido almacenados en el parámetro 'platos'
 * con un bucle 'for' para sumar en el 'acumuladorDePrecio', en cada iteración, el 'precio'
 * por la 'cantidad' de cada 'plato'
 * - Retornar el 'acumuladorDePrecio'
 */

type PrecioDelPedido = (pedido: Pedido) => number;
const precioDelPedido: PrecioDelPedido = function (pedido) {
  let acumuladorDePrecio: number = 0;
  for (let i = 0; i < pedido.length; i++) {
    acumuladorDePrecio += pedido[i].cantidad * pedido[i].plato.precio;
    console.log(
      pedido[i].plato.nombre,
      pedido[i].plato.precio,
      pedido[i].cantidad,
      "=",
      pedido[i].plato.precio * pedido[i].cantidad
    );
  }
  return acumuladorDePrecio;
};

console.log("Precio Total:", precioDelPedido(pedido));
